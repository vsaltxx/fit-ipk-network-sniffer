# Network Sniffer Documentation

## Executive Summary
This documentation provides an overview of the Network Sniffer project, detailing its functionality, implementation, testing, and additional features beyond the assignment requirements.

## Theory
The Network Sniffer is a tool designed to capture and analyze network packets. It utilizes various protocols such as TCP, UDP, ICMPv4, ICMPv6, ARP, NDP, IGMP, and MLD to intercept and inspect network traffic.

## Implementation
The project is implemented in C# and leverages the SharpPcap and PacketDotNet libraries for packet capturing and analysis. Below are the key components of the implementation:

1. **CLI Interface:**
- Provides a command-line interface for user interaction.
- Allows users to specify command-line arguments to configure packet capture options.
2. **Packet Capture Logic:**
- Utilizes SharpPcap library to capture network packets from the specified interface.
- Implements packet capture functionality to intercept data packets transmitted over the network.
3. **Filtering Mechanisms:**
- Enables users to define filters based on various criteria such as protocol type, port numbers, and packet content.
- Applies filters to selectively capture packets according to user-defined specifications.
4. **Packet Analysis Algorithms:**
- Utilizes PacketDotNet library for packet parsing and analysis.
- Implements algorithms to extract relevant information from captured packets, such as source and destination addresses, port numbers, and protocol types.

## Testing
The application was tested on Ubuntu 22.04 running in the Windows Subsystem for Linux (WSL) environment. Testing involved various scenarios to validate the functionality and performance of the network sniffer program. The testing environment consisted of the following components:

**Testing involved:**

- Capturing network packets using the specified command-line arguments.
- Verifying the correct interpretation of captured packets.
- Testing various edge cases, including:
- Different network protocols (TCP, UDP, ICMP, ARP, NDP, IGMP, MLD)
- Packet filtering with different criteria.
- Handling of unexpected or malformed packets.
- Ensuring the termination of the program with the Ctrl+C sequence.

## Additional Functionality
Beyond the assignment requirements, the Network Sniffer includes features such as graceful termination with Ctrl+C, flexible command-line argument parsing, and support for multiple network protocols.

## License
This project is licensed under the [GNU GENERAL PUBLIC LICENSE v3](https://www.gnu.org/licenses/gpl-3.0.html).

## Bibliography
- SharpPcap documentation: https://github.com/dotpcap/sharppcap
- PacketDotNet documentation: https://github.com/dotpcap/packetnet

