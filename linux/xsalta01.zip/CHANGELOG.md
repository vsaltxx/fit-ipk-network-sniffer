# Changelog

## [Unreleased]

### Added
- Implemented basic functionality of the sniffer with the ability to capture packets with various protocols.
- Added support for filtering by TCP, UDP, ICMPv4, ICMPv6, ARP, NDP, and IGMP protocols.
- Implemented display of information about captured packets, including metadata, MAC addresses, IP addresses, and ports.
- Added support for displaying packet data in hexadecimal dump format.
- Implemented command-line argument processing to control sniffer parameters such as interface, packet count, and filters.

### Changed
- Improved error and exception handling.
- Enhanced interrupt signal handling for proper program termination upon Ctrl+C.

### Fixed
- Fixed issue with command-line filter processing.
- Fixed problem with incorrect display of packet data in some cases.

## [1.0.0] - 2024-04-22

### Added
- Initial release.

